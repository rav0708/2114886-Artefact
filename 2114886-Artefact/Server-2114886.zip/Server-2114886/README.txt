##### SERVER CONFIGS OF SPOTTY - INSTRUCTION MANUAL#####

***IMPORTANT****

####Please find the apk file of SPOTTY : SPOTTY\app\build\outputs\apk\debug
Note : 
# Setup the absolute/relative paths in the Python Script according to your directories.
# (.ipynb file & .txt file have been provided)

REQUIREMENTS:
	Languages Installed : 	Python 2/3
					Anaconda
					Flask

	IDE 			  :	JupyterLab



Dataset URL:https://www.kaggle.com/asimislam/python-r-colors-and-palettes-data





